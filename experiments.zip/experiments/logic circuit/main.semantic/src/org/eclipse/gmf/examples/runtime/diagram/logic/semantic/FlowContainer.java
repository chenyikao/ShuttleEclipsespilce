/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.gmf.examples.runtime.diagram.logic.semantic;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flow Container</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmf.examples.runtime.diagram.logic.semantic.SemanticPackage#getFlowContainer()
 * @model
 * @generated
 */
public interface FlowContainer extends ContainerElement {
} // FlowContainer
