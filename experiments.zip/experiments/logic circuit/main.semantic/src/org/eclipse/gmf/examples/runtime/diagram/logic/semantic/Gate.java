/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.gmf.examples.runtime.diagram.logic.semantic;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gate</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.gmf.examples.runtime.diagram.logic.semantic.SemanticPackage#getGate()
 * @model abstract="true"
 * @generated
 */
public interface Gate extends Element {
} // Gate
