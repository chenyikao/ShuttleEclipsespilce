/*******************************************************************************
 * Copyright (c) 2008 Code 9 Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Code 9 Corporation - initial API and implementation
 *     Chris Aniszczyk <zx@code9.com>
 *******************************************************************************/
package com.code9.examples.spellchecking.handlers;

import java.util.Iterator;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.SubMenuManager;
import org.eclipse.jface.commands.ActionHandler;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.AnnotationModel;
import org.eclipse.jface.text.source.IAnnotationAccess;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ActiveShellExpression;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;
import org.eclipse.ui.handlers.IHandlerActivation;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.texteditor.AnnotationPreference;
import org.eclipse.ui.texteditor.DefaultMarkerAnnotationAccess;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.IWorkbenchActionDefinitionIds;
import org.eclipse.ui.texteditor.MarkerAnnotationPreferences;
import org.eclipse.ui.texteditor.SourceViewerDecorationSupport;

// for a more advanced example and inspiration of this code...
// see CommitCommentArea from org.eclipse.team.cvs.ui
public class TextBox {

	private final StyledText fTextField; // updated only by modify events
	private Composite fComposite;

	private String fText;

	public TextBox(Composite composite, String text) {

		fComposite= composite;

		AnnotationModel annotationModel = new AnnotationModel();
		IAnnotationAccess annotationAccess = new DefaultMarkerAnnotationAccess();

		Composite cc = new Composite(composite, SWT.BORDER);
		cc.setLayout(new FillLayout());
		cc.setLayoutData(new GridData(GridData.FILL_BOTH));

		final SourceViewer sourceViewer = new SourceViewer(cc, null, null, true, SWT.MULTI | SWT.V_SCROLL | SWT.WRAP);
		fTextField = sourceViewer.getTextWidget();
		fTextField.setIndent(2);

		final SourceViewerDecorationSupport support = new SourceViewerDecorationSupport(sourceViewer, null, annotationAccess, EditorsUI.getSharedTextColors());

		Iterator e= new MarkerAnnotationPreferences().getAnnotationPreferences().iterator();
		while (e.hasNext())
			support.setAnnotationPreference((AnnotationPreference) e.next());

		support.install(EditorsUI.getPreferenceStore());

		final IHandlerService handlerService= (IHandlerService)PlatformUI.getWorkbench().getService(IHandlerService.class);
		final IHandlerActivation handlerActivation= installQuickFixActionHandler(handlerService, sourceViewer);

		final TextViewerAction cutAction = new TextViewerAction(sourceViewer, ITextOperationTarget.CUT);
		cutAction.setText("Cut");
		cutAction.setActionDefinitionId(IWorkbenchActionDefinitionIds.CUT);

		final TextViewerAction copyAction = new TextViewerAction(sourceViewer, ITextOperationTarget.COPY);
		copyAction.setText("Copy");
		copyAction.setActionDefinitionId(IWorkbenchActionDefinitionIds.COPY);

		final TextViewerAction pasteAction = new TextViewerAction(sourceViewer, ITextOperationTarget.PASTE);
		pasteAction.setText("Paste");
		pasteAction.setActionDefinitionId(IWorkbenchActionDefinitionIds.PASTE);

		final TextViewerAction selectAllAction = new TextViewerAction(sourceViewer, ITextOperationTarget.SELECT_ALL);
		selectAllAction.setText("Select All");
		selectAllAction.setActionDefinitionId(IWorkbenchActionDefinitionIds.SELECT_ALL);            

		MenuManager contextMenu = new MenuManager();
		contextMenu.add(cutAction);
		contextMenu.add(copyAction);
		contextMenu.add(pasteAction);
		contextMenu.add(selectAllAction);
		contextMenu.add(new Separator());

		final SubMenuManager quickFixMenu = new SubMenuManager(contextMenu);
		quickFixMenu.setVisible(true);
		quickFixMenu.addMenuListener(new IMenuListener() {

			public void menuAboutToShow(IMenuManager manager) {
				quickFixMenu.removeAll();

				IAnnotationModel annotationModel = sourceViewer.getAnnotationModel();
				Iterator annotationIterator = annotationModel.getAnnotationIterator();
				while (annotationIterator.hasNext()) {
					Annotation annotation = (Annotation) annotationIterator.next();
					if (!annotation.isMarkedDeleted() && includes(annotationModel.getPosition(annotation), sourceViewer.getTextWidget().getCaretOffset()) && sourceViewer.getQuickAssistAssistant().canFix(annotation)) {
						ICompletionProposal[] computeQuickAssistProposals = sourceViewer.getQuickAssistAssistant().getQuickAssistProcessor().computeQuickAssistProposals(sourceViewer.getQuickAssistInvocationContext());
						for (int i = 0; i < computeQuickAssistProposals.length; i++) {
							final ICompletionProposal proposal = computeQuickAssistProposals[i];
							quickFixMenu.add(new Action(proposal.getDisplayString()) {

								/* (non-Javadoc)
								 * @see org.eclipse.jface.action.Action#run()
								 */
								public void run() {
									proposal.apply(sourceViewer.getDocument());
								}

								/* (non-Javadoc)
								 * @see org.eclipse.jface.action.Action#getImageDescriptor()
								 */
								public ImageDescriptor getImageDescriptor() {
									if (proposal.getImage() != null) {
										return ImageDescriptor.createFromImage(proposal.getImage());
									}
									return null;
								}
							});
						}
					}
				}
			}

		});

		fTextField.addFocusListener(new FocusListener() {

			IHandlerActivation cutHandlerActivation;
			IHandlerActivation copyHandlerActivation;
			IHandlerActivation pasteHandlerActivation;
			IHandlerActivation selectAllHandlerActivation;

			public void focusGained(FocusEvent e) {
				cutAction.update();
				copyAction.update();
				IHandlerService service = (IHandlerService) PlatformUI.getWorkbench().getService(IHandlerService.class);
				cutHandlerActivation = service.activateHandler(IWorkbenchActionDefinitionIds.CUT, new ActionHandler(cutAction), new ActiveShellExpression(fComposite.getShell()));
				copyHandlerActivation = service.activateHandler(IWorkbenchActionDefinitionIds.COPY, new ActionHandler(copyAction), new ActiveShellExpression(fComposite.getShell()));
				pasteHandlerActivation = service.activateHandler(IWorkbenchActionDefinitionIds.PASTE, new ActionHandler(pasteAction), new ActiveShellExpression(fComposite.getShell()));				selectAllHandlerActivation = service.activateHandler(IWorkbenchActionDefinitionIds.SELECT_ALL, new ActionHandler(selectAllAction), new ActiveShellExpression(fComposite.getShell()));
			}

			/* (non-Javadoc)
			 * @see org.eclipse.swt.events.FocusAdapter#focusLost(org.eclipse.swt.events.FocusEvent)
			 */
			public void focusLost(FocusEvent e) {
				IHandlerService service = (IHandlerService) PlatformUI.getWorkbench().getService(IHandlerService.class);

				if (cutHandlerActivation != null) {
					service.deactivateHandler(cutHandlerActivation);
				}

				if (copyHandlerActivation != null) {
					service.deactivateHandler(copyHandlerActivation);
				}

				if (pasteHandlerActivation != null) {
					service.deactivateHandler(pasteHandlerActivation);
				}

				if (selectAllHandlerActivation != null) {
					service.deactivateHandler(selectAllHandlerActivation);
				}
			}

		});

		sourceViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			public void selectionChanged(SelectionChangedEvent event) {
				cutAction.update();
				copyAction.update();
			}

		});

		sourceViewer.getTextWidget().addDisposeListener(new DisposeListener() {

			public void widgetDisposed(DisposeEvent e) {
				support.uninstall();
				handlerService.deactivateHandler(handlerActivation);
			}

		});

		// this is where the magic happens for spellchecking
		// see org.eclipse.jface.text.source.TextSourceViewerConfiguration#getReconciler
		Document document = new Document(text);
		sourceViewer.configure(new TextSourceViewerConfiguration(EditorsUI.getPreferenceStore()));
		sourceViewer.setDocument(document, annotationModel);

		fTextField.setMenu(contextMenu.createContextMenu(fTextField));
		fTextField.selectAll();
	}

	protected boolean includes(Position position, int caretOffset) {
		return position.includes(caretOffset) || (position.offset + position.length) == caretOffset;
	}

	private IHandlerActivation installQuickFixActionHandler(IHandlerService handlerService, SourceViewer sourceViewer) {
		return handlerService.activateHandler(
				ITextEditorActionDefinitionIds.QUICK_ASSIST,
				createQuickFixActionHandler(sourceViewer),
				new ActiveShellExpression(sourceViewer.getTextWidget().getShell()));
	}

	private ActionHandler createQuickFixActionHandler(final ITextOperationTarget textOperationTarget) {
		Action quickFixAction= new Action() {
			/* (non-Javadoc)
			 * @see org.eclipse.jface.action.Action#run()
			 */
			public void run() {
				textOperationTarget.doOperation(ISourceViewer.QUICK_ASSIST);
			}
		};
		quickFixAction.setActionDefinitionId(ITextEditorActionDefinitionIds.QUICK_ASSIST);
		return new ActionHandler(quickFixAction);    		
	}

	public void setEnabled(boolean enabled) {
		fTextField.setEnabled(enabled);
	}

	public String getText() {
		return fText;
	}

	public void setFocus() {
		fTextField.setFocus();
	}
    
}
