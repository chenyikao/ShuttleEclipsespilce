/*******************************************************************************
 * Copyright (c) 2008 Code 9 Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Code 9 Corporation - initial API and implementation
 *     Chris Aniszczyk <zx@code9.com>
 *******************************************************************************/
package com.code9.examples.spellchecking.handlers;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.FormDialog;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class ExampleDialog extends FormDialog {

	public ExampleDialog(Shell shell) {
		super(shell);
	}

	protected void createFormContent(IManagedForm mform) {
		mform.getForm().setText("Spell Checking Dialog");
		FormToolkit toolkit = mform.getToolkit();
		Composite container = mform.getForm().getBody();
		container.setLayout(new GridLayout());
		container.setLayoutData(new GridData(GridData.FILL_BOTH));
		toolkit.decorateFormHeading(mform.getForm().getForm());
		
		Composite composite = toolkit.createComposite(container);
		composite.setLayout(new GridLayout());
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));
		TextBox box = new TextBox(composite, "A cat goes meow and a dog goes bark.");
		box.setEnabled(true);
	}
	
}
